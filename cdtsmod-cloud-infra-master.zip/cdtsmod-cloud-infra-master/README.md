To creating the resources, need to run these terraform scripts from this below url based on the parameters that is needed.
https://jenkins.tmna-devops.com/job/CDTSMOD/job/deploys/job/subprod/job/deployTerraformStandalone
